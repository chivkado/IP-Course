<template>
  <ul class="todo-list">
    <li v-for="task in tasks" :key="task.id" class="task-item">
      <span :class="{ done: task.completedAt }">
        {{ task.text }}
      </span>

      <div class="actions">
        <button v-if="!task.completedAt" @click="complete(task)">✅ Complete</button>
        <button @click="remove(task)">🗑️ Delete</button>
      </div>
    </li>
  </ul>
</template>

<script setup>
import { todoStore } from '../stores/todo.js'
defineProps({ tasks: Array })

async function complete(task) {
  if (!task.completedAt) {
    await todoStore.markAsDone(task.id)
  }
}
async function remove(task) {
  await todoStore.deleteTodo(task.id)
}
</script>

<style scoped>
.todo-list {
  list-style: none;
  padding: 0;
}

.task-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.6rem 0;
  border-bottom: 1px solid #ddd;
}

.done {
  text-decoration: line-through;
  color: gray;
}

.actions {
  display: flex;
  gap: 0.5rem;
}
button {
  cursor: pointer;
  padding: 0.2rem 0.6rem;
}
</style>
