<template>
  <div class="container">
    <h2>✅ Todo App</h2>

    <!-- Add Task Form -->
    <AddTodo @taskAdded="todoStore.fetchTodos" />

    <!-- Task Summary -->
    <div class="summary">
      <p>📝 You have <strong>{{ pendingTasks.length }}</strong> pending tasks.</p>
    </div>

    <!-- Pending Tasks -->
    <h3>Pending Tasks</h3>
    <TodoList :tasks="pendingTasks" />

    <!-- Completed Tasks -->
    <h3>Completed Tasks</h3>
    <TodoList :tasks="completedTasks" />
  </div>
</template>

<script setup>
import AddTodo from './components/AddTodo.vue'
import TodoList from './components/TodoList.vue'
import { computed, onMounted } from 'vue'
import { todoStore } from './stores/todo.js'

// Fetch on first load
onMounted(todoStore.fetchTodos)

// Computed lists
const pendingTasks = computed(() =>
  todoStore.todos.filter(task => !task.completedAt)
)

const completedTasks = computed(() =>
  todoStore.todos.filter(task => task.completedAt)
)
</script>

<style>
.container {
  max-width: 600px;
  margin: auto;
  padding: 1rem;
  font-family: sans-serif;
}

.summary {
  margin-bottom: 1rem;
  font-size: 1rem;
}
</style>
