import { reactive } from 'vue'
import axios from 'axios'

export const todoStore = reactive({
  todos: [],

  async fetchTodos() {
    const res = await axios.get('http://localhost:3100/tasks')
    this.todos = res.data
  },

  async addTodo(text) {
    const res = await axios.post('http://localhost:3100/tasks', {
      text,
      createdAt: new Date().toISOString(),
      completedAt: null
    })
    this.todos.push(res.data)
  },

  async markAsDone(id) {
    const res = await axios.patch(`http://localhost:3100/tasks/${id}`, {
      completedAt: new Date().toISOString()
    })
    const index = this.todos.findIndex(t => t.id === id)
    if (index !== -1) this.todos[index] = res.data
  },

  async deleteTodo(id) {
    await axios.delete(`http://localhost:3100/tasks/${id}`)
    this.todos = this.todos.filter(t => t.id !== id)
  }
})
